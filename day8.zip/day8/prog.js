function start()

cdir := "D:\Prog\_adventofcode2019\day8\"
cdir := "C:\_Arne\_adventofcode2019\day8\"
c := FExecuteVOScriptFile(cdir +"\prog.js", "Task",{cdir, 0})
return

function Task(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

cfile := cdir+"input.txt"
c := ffileread(cfile)
a := {}
cout := ""
n0min := 9999

do while !Empty(c)
cx := substr(c, 1, 150)

AAdd (a, cx)
c := substr(c, 151)
enddo

cout := ""

for iy := 1 upto 6
	for ix := 1 upto 25
		nindex := (iy-1)*25+ix
		for ilayer := 1 upto alen(a)
			c := substr(a[ilayer], nindex, 1)
			if c == "0" .or. c == "1"
			if c == "0"
			c := "_"
			endif
				cout += c 
				exit
			endif	  
		next 
		
	next
	cout += crlf
	
next
msginfo (cout)

dlgProgressClose(getshell())

return 


n0 := 0
n1 := 0
n2 := 0
for i := 1 upto len(cx)
	c1 := substr(cx, i, 1)
	if c1 == "0"
		n0 +=1
	elseif c1 == "1"
		n1 +=1
	elseif c1 == "2"
		n2 +=1
	endif
next
cout += typevalue2string(i, n0, n1, n2, n1*n2)+crlf
if n0 < n0min 
	n0min := n0
	n1n2 := n1*n2
endif
