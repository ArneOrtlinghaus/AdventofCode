function start()
cdir := "D:\Prog\_adventofcode2019\day6\"
cdir := "C:\_Arne\_adventofcode2019\day6\"
c := FExecuteVOScriptFile(cdir +"\prog.js", "Task",{cdir, 0})
return

function Task(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

cfile := cdir+"input.txt"
c := ffileread(cfile)
//c := "3,9,8,9,10,9,4,9,99,-1,8"
//c := "3,9,7,9,10,9,4,9,99,-1,8"
//c := "3,3,1108,-1,8,3,4,3,99"
//c := "3,3,1107,-1,8,3,4,3,99"
//c := "3,31,3,32,1002,32,10,32,1001,31,-2,31,1007,31,0,33,1002,33,7,33,1,33,31,31,1,32,31,31,4,31,99,0,0,0"
c := strtran(c, " ", "")
a := string2array(c, crlf)
for i := 1 upto alen(a)
   c := a[i] 
   a2 := string2array(c, ")")
   aadd (a2, 0)
   arrayputmacro(a, i, a2)
next  

macrofunc("calctree2", {a})

//msginfo (typevalue2string(a))

cway := macrofunc("calcwayfromtocom", {a, "YOU"})
cway2 := macrofunc("calcwayfromtocom", {a, "SAN"})
msginfo (cway+crlf+crlf+cway2)
dlgProgressClose(getshell())

return 

function calcwayfromtocom(a, cf)
cway := ""

for i := 1 upto alen(a)
dlgprogressupdatetext(getshell(), "num  " + typevalue2string(i)
    if a[i,2] == cf
    nindex := a[i,3]
	do while nindex > 0
	   cway += typevalue2string(a[nindex,1],a[nindex,2])+crlf
	   nindex := a[nindex,3]
	   
	enddo
	endif
next

return cway

function calcnum(a)
n:= 0

for i := 1 upto alen(a)
dlgprogressupdatetext(getshell(), "num  " + typevalue2string(i)
    
    nindex := a[i,3]
	n += 1
	do while nindex > 0
	   n += 1
	   nindex := a[nindex,3]
	   
	enddo
next

return n

function calctree2(a)

for i := 1 upto alen(a)
dlgprogressupdatetext(getshell(), "calc " + typevalue2string(i))

cf := a[i,2]
ct := a[i,1]

if !(ct == "COM") 
	i2 := 1
	lfound := false
	do while !lfound .and. i2 <= alen(a) 
		if (ct == a[i2,2]) 
		   lfound := true
			APutTwo(a, i, 3, i2)
	       
		endif
		i2+=1
	enddo
endif


next
return 

function calctree(a)
atree := {}
for i := 1 upto alen(a)
dlgprogressupdatetext(getshell(), "calc " + typevalue2string(i))

anew := {}
aadd (anew, a[i])

cf := a[i,2]
ct := a[i,1]
iloop := 0
do while !(ct == "COM") .and. iloop < 1000
dlgprogressupdatetext(getshell(), "calc " + typevalue2string(i,iloop))
	iloop +=1 
	i2 := 1
	lfound := false
	do while !lfound .and. i2 <= alen(a) 
		if (ct == a[i2,2]) 
		   lfound := true
			aadd (anew, a[i2])
			cf := a[i2,2]
			ct := a[i2,1]
		endif
		i2+=1
	enddo
enddo

aadd (atree, anew)
next
return atree
