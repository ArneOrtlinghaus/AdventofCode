function start()
cdir := "D:\Prog\_adventofcode2019\day12\"
cdir := "C:\_Arne\_adventofcode2019\day12\"
c := FExecuteVOScriptFile(cdir +"\prog.js", "Task2",{cdir, 0})
return

function Task2(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)
ares := {}
apos := {}
aadd (apos, {-4, 3, 15})
aadd (apos, {-11, -10, 13})
aadd (apos, {2, 2, 18})
aadd (apos, {7, -1, 0})
aposst := ACloneMacro (apos)
av := {}
aadd (av, {0, 0, 0})
aadd (av, {0, 0, 0})
aadd (av, {0, 0, 0})
aadd (av, {0, 0, 0})
avst := ACloneMacro (av)
f := seconds()
iloop := 0
ik := 0
c := ntrim(iloop)+ " "+ntrim(ik)+ " "+str(seconds()-f,-1,3)+ " "+typevalue2string(ares)
				ffileappend(cdir+"output.txt", c)
for iloop := 1 upto 1000000000
dlgprogressupdatetext(getshell(), ntrim(iloop)+ " "+str(seconds()-f,-1,3)+ " "+typevalue2string(ares))
	for ik := 1 upto 3
		for i1 := 1 upto 4
			for i2 := 1 upto 4
				if i1<>i2
				
					k1 := apos[i1,ik]
					v1 := av[i1,ik]
					k2 := apos[i2,ik]
					if k2 > k1 
						v1+= 1
					elseif k2 < k1 
						v1-= 1
					endif
					APutTwo(av, i1, ik, v1)
				
				endif
			next
		next
	next
	
	for ik := 1 upto 3
		for i1 := 1 upto 4
		
			k1 := apos[i1,ik]
			v1 := av[i1,ik]
			k1 += v1
			APutTwo(apos, i1, ik, k1)
		next
		if apos[1,ik] == aposst[1,ik] .and. apos[2,ik] == aposst[2,ik] .and. apos[3,ik] == aposst[3,ik] .and. apos[4,ik] == aposst[4,ik]
			if av[1,ik] == avst[1,ik] .and. av[2,ik] == avst[2,ik] .and. av[3,ik] == avst[3,ik] .and. av[4,ik] == avst[4,ik]
				aadd (ares, {ik, iloop})
				c := ntrim(iloop)+ " "+ntrim(ik)+ " "+str(seconds()-f,-1,3)+ " "+typevalue2string(ares)
				ffileappend(cdir+"output.txt", c)
			endif
		endif
	next
next


dlgProgressClose(getshell())

msginfo(typevalue2string(ares))
return 

function Task1(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

apos := {}
aadd (apos, {-4, 3, 15})
aadd (apos, {-11, -10, 13})
aadd (apos, {2, 2, 18})
aadd (apos, {7, -1, 0})

av := {}
aadd (av, {0, 0, 0})
aadd (av, {0, 0, 0})
aadd (av, {0, 0, 0})
aadd (av, {0, 0, 0})
f := seconds()
for iloop := 1 upto 1000000
dlgprogressupdatetext(getshell(), ntrim(iloop)+ " "+str(seconds()-f,-1,3))
	for i1 := 1 upto 4
		for i2 := 1 upto 4
			if i1<>i2
				for ik := 1 upto 3
					k1 := apos[i1,ik]
					v1 := av[i1,ik]
					k2 := apos[i2,ik]
					if k2 > k1 
						v1+= 1
					elseif k2 < k1 
						v1-= 1
					endif
					APutTwo(av, i1, ik, v1)
				next
			endif
		next
	next
	
	for i1 := 1 upto 4
		for ik := 1 upto 3
			k1 := apos[i1,ik]
			v1 := av[i1,ik]
			k1 += v1
			APutTwo(apos, i1, ik, k1)
		next
	next
next

e := 0
for i1 := 1 upto 4
	k1 := 0
	v1 := 0
	for ik := 1 upto 3
		k1 += abs(apos[i1,ik])
		v1 += abs(av[i1,ik])
	next
	e += k1*v1
next

dlgProgressClose(getshell())

msginfo(typevalue2string(e))
return 

