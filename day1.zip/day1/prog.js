function example() 
cdir := "D:\Prog\_adventofcode2019\day1\"
c := FExecuteVOScriptFile(cdir+"\prog.js", "Task0", {cdir})
return

function Task0(cdir) 
a := {}
AAdd (a, 12)
AAdd (a, 14)
AAdd (a, 1969)
AAdd (a, 100756)
MacroFunc("Getfuelarray",{a})
return 

function Task1(cdir) 
cfile := cdir+"input1.txt"
c := ffileread(cfile)
a := string2array(c, crlf)
nsum := 0 
c := ""
for i := 1 upto alen(a)
	m := val(alltrim(a[i]))
	ArrayPutMacro(a, i, m)
next 
MacroFunc("Getfuelarray",{a})
return

function Getfuelarray(a)
c := ""
nsum := 0
for i := 1 upto alen(a)
	m := a[i]
	//n := MacroFunc("getfuel",{m})
	n := MacroFunc("getfuelrec",{m})
	nsum += n
	c += typevalue2string(m, n)+crlf
next 
	c += "sum: " + typevalue2string(nsum)+crlf
msginfo (c)
return

//Fuel required to launch a given module is based on its mass. Specifically, to find //the fuel required for a module, take its mass, divide by three, round down, and //subtract 2.

//    For a mass of 12, divide by 3 and round down to get 4, then subtract 2 to get 2.
//For a mass of 14, dividing by 3 and rounding down still yields 4, so the fuel required is also 2.
//    For a mass of 1969, the fuel required is 654.
//    For a mass of 100756, the fuel required is 33583.

function getfuel(mmass)
f :=(mmass -mmass % 3) / 3
f -= 2
return f

function getfuelrec(mmass)
fsum := 0
f := MacroFunc("getfuel",{mmass})
do while f > 0
	fsum += f 
	f := MacroFunc("getfuel",{f})
enddo
return fsum