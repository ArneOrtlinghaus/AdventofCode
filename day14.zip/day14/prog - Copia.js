function Task0 (cdir, ntask, coutfile) 

cfile := cdir+"inpu0c.txt"
c := ffileread(cfile)
ainput := string2array(c, crlf)
for i := 1 upto alen(ainput)
a := string2array(ainput[i], "=>")
cl := alltrim(a[1])
cr := alltrim(a[2])
a := string2array(cr, " ")
n := val(a[1])
cr := (a[2])
al := {}
ax := string2array(cl, ",")
for il := 1 upto alen(ax)
	c := alltrim(ax[il])
	a := string2array(c, " ")
	nl := val(a[1])
	cl := (a[2])
	aadd (al, {cl,nl})
next

a := {cr, n, al,0,0}
APutone (ainput,i, a)
next
asort := {}
aadd (asort, ainput[1])
for i := 2 upto alen(ainput)
	a := ainput[i]
	lfound := false 
	j := 1
	cr := ainput[i,1]
	al := ainput[i,3]
	do while !lfound .and. j <= alen(asort)
		lfoundl := false
		for il := 1 upto alen(al)
			if cr == al[il,1]
				lfoundl := true
				exit
			endif
		next
		if !lfoundl
			lfound := true
			aein (asort, j, ainput[i])
		endif
		j += 1
	enddo
	if !lfound
		aadd (asort, ainput[i])
	endif
next

//msginfo(typevalue2string(asort))

aputtwo(asort, 1,4, 1)
nore := 0
for i := 1 upto alen(asort)
	cf := asort[i,1]
	nr := asort[i,2]
	n := asort[i,4]
	nfak := 1
	nx := nr
	do while nx < n
		nx += nr
		nfak += 1
	enddo
	//if cf == "AB"
		//	msginfo (typevalue2string(cf, i, nr, n, nfak,nx,asort[i]))
	//endif
	al := asort [i,3]
	for il := 1 upto alen(al)
		cl := al[il,1]
		nr := al[il,2]
		
		npos := ascanmacro(asort, cl,1)
		
		if npos > 0
			nl := asort[npos,4]
			
			//if cl == "A"
			//msginfo (typevalue2string(cf, i, cl, nl, nl += nr*nfak, "nr", nr, "nfak",nfak,n, cf,asort[i]))
			//endif
			
			nl += nr*nfak
			
			aputtwo(asort, npos,4, nl)
		elseif cl == "ORE"
		//msginfo ("ORE"+typevalue2string(i, nore, nr*nfak,nore+nr*nfak,asort[i]))
			nore += nr*nfak
			
		else 
			msgwarning("not found "+typevalue2string(cl))
		endif
	next
next

msginfo(typevalue2string(nore, asort))


return 


{"FUEL", 1, {{"A", 7}, {"E", 1}}, 0, 0}
{"E", 1, {{"A", 7}, {"D", 1}}, 0, 0}
{"D", 1, {{"A", 7}, {"C", 1}}, 0, 0}
{"C", 1, {{"A", 7}, {"B", 1}}, 0, 0}
{"B", 1, {{"ORE", 1}}, 0, 0}
{"A", 10, {{"ORE", 10}}, 0, 0}



cfile := cdir+"input.txt"
c := ffileread(cfile)
//c := "109,1,204,-1,1001,100,1,100,1008,100,16,101,1006,101,0,99"
//c := "1102,34915192,34915192,7,4,7,99,0"
//c := "104,1125899906842624,99"
c := strtran(c, " ", "")
a := string2array(c, ",")
for i := 1 upto alen(a)
   n := a[i] 
   arrayputmacro(a, i, val(n))
next  
