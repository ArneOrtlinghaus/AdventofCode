function Task1 (cdir) 

a := macrofunc ("makearray",{cdir})

nfuel := 1
do while !empty(nfuel)
nfuel := inputvalue (getshell(), "fuel", nfuel)
if !empty(nfuel)
nore := macrofunc ("calc",{cdir, a, nfuel})
endif
enddo
return 

function calc (cdir, asort, nfuel)
//msginfo(typevalue2string(asort))
asort := aclonemacro(asort)

aputtwo(asort, 1,4, nfuel)
nore := 0
for i := 1 upto alen(asort)
	cf := asort[i,1]
	dlgprogressupdatetext(getshell(), cf + " "+ntrim(i))
	nr := asort[i,2]
	n := asort[i,4]
	nfak := 1
	nx := nr
	dlgprogressupdatetext(getshell(), cf + " "+ntrim(i)+ " "+ntrim(nx)+ " "+ntrim(n))
	nfak := integer(rundung((1.0*n)/(1.0*nr),1,2))
	//do while nx < n
	//	nx += nr
	//	nfak += 1
	//enddo
	APuttwo (asort,i, 5, nfak)
	APuttwo (asort,i, 6, nfak*nr)
	//if cf == "AB"
		//	msginfo (typevalue2string(cf, i, nr, n, nfak,nx,asort[i]))
	//endif
	al := asort [i,3]
	for il := 1 upto alen(al)
		cl := al[il,1]
		nr := al[il,2]
		dlgprogressupdatetext(getshell(), cf + " "+ntrim(i)+ " "+cl + ntrim(nr))
		
		npos := ascanmacro(asort, cl,1)
		
		if npos > 0
			nl := asort[npos,4]
			
			//if cl == "A"
			//msginfo (typevalue2string(cf, i, cl, nl, nl += nr*nfak, "nr", nr, "nfak",nfak,n, cf,asort[i]))
			//endif
			
			nl += nr*nfak
			
			aputtwo(asort, npos,4, nl)
		elseif cl == "ORE"
		//msginfo ("ORE"+typevalue2string(i, nore, nr*nfak,nore+nr*nfak,asort[i]))
			nore += nr*nfak
			
		else 
			msgwarning("not found "+typevalue2string(cl))
		endif
	next
next

ffileappend(cdir+"output.txt",typevalue2string(nfuel, nore)+crlf)
msginfo(typevalue2string(nfuel, nore))

return nore

function makearray(cdir)
cfile := cdir+"input.txt"
c := ffileread(cfile)
ainput := string2array(c, crlf)
for i := 1 upto alen(ainput)
a := string2array(ainput[i], "=>")
cl := alltrim(a[1])
cr := alltrim(a[2])
a := string2array(cr, " ")
n := val(a[1])
cr := (a[2])
al := {}
ax := string2array(cl, ",")
for il := 1 upto alen(ax)
	c := alltrim(ax[il])
	a := string2array(c, " ")
	nl := val(a[1])
	cl := (a[2])
	aadd (al, {cl,nl})
next

a := {cr, n, al,0,0,0}
APutone (ainput,i, a)
next


asort := {}
do while alen(ainput) > 0
for i := 1 upto alen(ainput)
	a := ainput[i]
	al := ainput[i,3]
	lfound := false
	for il := 1 upto alen(al)
		cl := al[il,1]
		if ascanmacro(ainput,cl, 1) > 0
			lfound := true
		endif
	next
	if !lfound
		aein (asort, 1,ainput[i])
		aaus (ainput, i)
	endif
next
enddo

return asort