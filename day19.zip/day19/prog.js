function Task2(cdir, ntask) 


aintcode := macrofunc ("readintcode", {cdir})

ix := 1
iy := 1
do while !empty(ix)
	ix := inputvalue (getshell(), "ix", ix)
	iy := inputvalue (getshell(), "iy", iy)
	if !empty(ix)
		nout := macrofunc ("getres",{cdir, aintcode, ix,iy})
		
		nx := 1
		ixn := ix+1
		do while nout > 0
			nout := macrofunc ("getres",{cdir, aintcode, ixn,iy})
			if nout > 0
				ixn += 1
				nx += 1
			endif
		enddo
		
		nout := 1
		ny := 1
		iyn := iy+1
		do while nout > 0
			nout := macrofunc ("getres",{cdir, aintcode, ix,iyn})
			if nout > 0
				iyn += 1
				ny += 1
			endif
		enddo
		
		c := typevalue2string(ix, iy, nout, nx, ny)
		ffileappend(cdir+"output.txt",c+crlf)
		msginfo (c)
	endif
enddo


return 

function getres (cdir, aintcode, ix,iy)
ainput := {ix, iy}

aout := macrofunc ("calcintcode", {aintcode, ainput})
nout:= aout[1]

return nout

function readintcode(cdir) 

cfile := cdir+"input.txt"
c := ffileread(cfile)
//c := "109,1,204,-1,1001,100,1,100,1008,100,16,101,1006,101,0,99"
//c := "1102,34915192,34915192,7,4,7,99,0"
//c := "104,1125899906842624,99"
c := strtran(c, " ", "")
a := string2array(c, ",")
for i := 1 upto alen(a)
   n := a[i] 
   arrayputmacro(a, i, val(n))
next  

return a

function calcintcode (a, ainput)
lgoon := true 
a := aclonemacro(a)
for i := 1 upto 100//00
aadd (a,0)
next
nmax := 0
nout := 0
coutput := ""
lhalt := false
istep := 0
ninput := 0
nbase := 0
cprot := ""

do while lgoon 
	nmax +=1
	
    istep1 := istep+1
	nopcode := a[istep1]
	copcode := strzero(nopcode,5,0)
	nopcode := val(substr(copcode, 4,2))
	cpmmode1 := substr(copcode, 3,1)
	cpmmode2 := substr(copcode, 2,1)
	cpmmode3 := substr(copcode, 1,1)
	//cprot += crlf+typevalue2string(copcode, "OP", nopcode)+crlf
	//cprot += "       "+typevalue2string(cpmmode1, cpmmode2, cpmmode3, istep)+crlf
	//cprot += "       "+typevalue2string(a[istep1], a[istep1+1], a[istep1+2], a[istep1+3])+crlf 
	//coutput += "OP"+typevalue2string(nopcode, istep) 
	if nopcode == 99
		lgoon := false 
		lhalt := true
	elseif nopcode == 1 .or. nopcode == 2
		if cpmmode1 == "0" 
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2"    
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0" 
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		elseif cpmmode2 == "2" 
			npos2 := a[istep1+2]
			npos2 += nbase
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if nopcode == 1 
		   nr := n1+n2 
		   //cprot += "       +"+typevalue2string(n1,n2,nr)+crlf 
		elseif nopcode == 2 
			nr := n1*n2 
			//cprot += "       x"+typevalue2string(n1,n2,nr)+crlf 
		endif
		 
		if cpmmode3 =="1" 
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		
		npos3 := a[istep1+3]
		if cpmmode3 == "2"
			npos3 += nbase
		endif
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	elseif nopcode == 3 .or. nopcode == 4
		if nopcode == 3
			ninput += 1
			nr := ainput[ninput]
				
			npos3 := a[istep1+1]
			if cpmmode1 == "2"
				npos3 += nbase
			endif
			//cprot += "      IN"+typevalue2string(nr, ninput, npos3)+crlf 
			arrayputmacro(a, npos3+1, nr)
		else 
			if cpmmode1 == "0" 
				npos1 := a[istep1+1]
				n1 := a[npos1+1]
			elseif cpmmode1 == "2" 
				npos1 := a[istep1+1]
				npos1 += nbase
				n1 := a[npos1+1]
			else 
				n1 := a[istep1+1]
			endif
			//cprot += "     OUT"+typevalue2string(n1)+crlf
			nout := n1
			coutput += str(nout, -1,0) +" "
			
		endif
		istep += 2
	elseif nopcode == 5 .or. nopcode == 6
	// Opcode 5 is jump-if-true: if the first parameter is non-zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
    // Opcode 6 is jump-if-false: if the first parameter is zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
		if cpmmode1 == "0"  
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2" 
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0" 
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		elseif cpmmode2 == "2" 
			npos2 := a[istep1+2]
			npos2 += nbase
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 5 .and. n1 <> 0) 
			istep := n2 
			//cprot += "     JPTRUE <> 0"+typevalue2string(n1, n2)+crlf
		elseif nopcode == 6 .and. n1 == 0)
			istep := n2 
			//cprot += "     JPFALSE == 0"+typevalue2string(n1, n2)+crlf
		else 
			istep += 3 
			if nopcode == 5
				//cprot += "     NO JPbecause false,==0"+typevalue2string(n1, n2)+crlf
			else
				//cprot += "     NO JPbecause true,<>0"+typevalue2string(n1, n2)+crlf
			endif
		endif
	elseif nopcode == 7 .or. nopcode == 8
    // Opcode 7 is less than: if the first parameter is less than the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.
    // Opcode 8 is equals: if the first parameter is equal to the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.		
		if cpmmode1 == "0"  
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2" 
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"  
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		elseif cpmmode2 == "2"  
			npos2 := a[istep1+2]
			npos2 += nbase
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 7 .and. n1 < n2) 
			nr := 1
			//cprot += "     LT"+typevalue2string(n1, n2)+crlf
		elseif nopcode == 8 .and. n1 == n2)
			nr := 1
			//cprot += "     EQ"+typevalue2string(n1, n2)+crlf
		else 
			nr := 0
			if nopcode == 7
				//cprot += "     0 because GE"+typevalue2string(n1, n2)+crlf
			else
				//cprot += "     0 because NE"+typevalue2string(n1, n2)+crlf
			endif
		endif
		
		if cpmmode3 =="1" 
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		
		npos3 := a[istep1+3]
		if cpmmode3 == "2" 
			npos3 += nbase
		endif
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	elseif nopcode == 9
	// Opcode 9 adjusts the relative base by the value of its only parameter. The relative base increases (or decreases, if the value is negative) by the value of the parameter.
		if cpmmode1 == "0" 
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2"    
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		nbase += n1
		//cprot += "     NBASE"+typevalue2string(n1, nbase)+crlf
		istep += 2
	else 
		msgerror ("not allowed opcode" + typevalue2string(istep, copcode))
	endif
	if nmax > 999999
		msgerror ("too many iterations")
		exit
	endif
enddo

return {nout, coutput, istep, cprot}



function Task1(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

aintcode := macrofunc ("readintcode", {cdir})

ab := {}
for iy := 1 upto 50
abx := {}
for ix := 1 upto 50
ainput := {ix-1, iy-1}

aout := macrofunc ("calcintcode", {aintcode, ainput})
nout:= aout[1]
c := typevalue2string(ix,iy,nout)
dlgprogressupdatetext(getshell(), c)
aadd (abx, nout)
next 
aadd (ab, abx)
next

ffilewrite(cdir+"outgl.txt",valuetosettingsstring(ab))
msginfo (typevalue2string(ab))

//coutput:= aout[2]

//msginfo (typevalue2string(aout))

dlgProgressClose(getshell())

return 