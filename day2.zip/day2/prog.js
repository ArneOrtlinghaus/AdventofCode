function start()
cdir := "D:\Prog\_adventofcode2019\day2\"
c := FExecuteVOScriptFile(cdir +"\prog.js", "Task",{cdir, 0})
return

function Task(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

cfile := cdir+"input1.txt"
c := ffileread(cfile)
c := strtran(c, " ", "")
a := string2array(c, ",")
for i := 1 upto alen(a)
   n := a[i] 
   arrayputmacro(a, i, val(n))
next  

if ntask == 1
n := macrofunc ("calc", {a, 12, 2})
msginfo (typevalue2string(n, a))
else 
	astart := a
    lfound := false
	for i1 := 0 upto 99
		dlgProgressUpdateText(getshell(), ntrim(i1))
		for i2 := 0 upto 99
			a := {}
			for i := 1 upto alen(astart)
				Aadd (a, astart[i])
			next
			n := macrofunc ("calc", {a, i1, i2})
			if n == 19690720
				lfound := true 
				msginfo (typevalue2string(i1, i2))
			endif
			if lfound 
				exit
			endif
		next 
		if lfound 
			exit
		endif
	   if( dlgProgressCanceled(getshell()))
			lfound := true
		endif
	next
	if !lfound 
		msginfo ("Nothing found")
	endif
endif 
dlgProgressClose(getshell())

return 

function calc (a, nstart1, nstart2)
//replace position 1 with the value 12 
arrayputmacro(a, 1+1, nstart1)
//and replace position 2 with the value 2 
arrayputmacro(a, 1+2, nstart2)

istep := 0
lgoon := true 
do while lgoon 
    istep1 := istep+1
	n := a[istep1]
	if n == 99
		lgoon := false 
	else
		npos1 := a[istep1+1]
		npos2 := a[istep1+2]
		npos3 := a[istep1+3]
		n1 := a[npos1+1]
		n2 := a[npos2+1]
		if n = 1 
		   nr := n1+n2 
		else 
			nr := n1*n2 
		endif 
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	endif
enddo

return a[1]
