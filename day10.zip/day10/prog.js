function start()
cdir := "D:\Prog\_adventofcode2019\day10\"
cdir := "C:\_Arne\_adventofcode2019\day10\"
c := FExecuteVOScriptFile(cdir +"\prog.js", "Task",{cdir, 0})
return


function Task2 (cdir, ntask, coutfile) 
//msginfo(typevalue2string(ainput))
cfile := cdir+"input.txt"
c := ffileread(cfile)
a := string2array(c, crlf)
iy := 37
ix := 27 


	dlgprogressupdatetext(getshell(), typevalue2string(iy, ix))
	ac := macrofunc("calccoord", {a, iy, ix})
	//call += typevalue2string(iy, ix, ":", nvisib)+CRLF

ASortTwoDim(ac, 1, true)

cphibef := "?"
ivap := 0
do while ivap < 200
for i := 1 upto alen(ac)
	cphi := ac[i][2]
	nvap := ac[i][3]
	if !(cphibef == cphi) .and. nvap == 0
		ivap += 1
		APutTwo(ac, i, 3, ivap)
	endif
	cphibef := cphi
next 
enddo
msginfo (typevalue2string(ac))
return 


function calccoord (a, iy, ix)


ac := {}
for iyt := 1 upto alen(a)
	c := a[iyt]
	for ixt := 1 upto len(c)
		if ixt <> ix .or. iyt <> iy
			cp := substr(c, ixt, 1)
			if cp == "#"
				acx := macrofunc("calcdiffex",{ iy, ix,iyt, ixt})
				aadd (ac, acx)
					
				
			endif
		endif
	next 
next

return ac

function calcdiffex (iy, ix, iyt, ixt)
xd := ixt -ix
yd := iyt -iy
r := xd *xd +yd *yd
r := sqrt(r)
xd := integer((1000.0 *xd) /r)
yd := integer((1000.0 *yd) /r)

if     xd == 0 .and. yd < 0 // nach oben
	cphieq := "1"
	f := 0
elseif xd > 0 .and. yd < 0
	cphieq := "2"
	f := (1.0*xd)/(1.0*yd)
elseif xd > 0 .and. yd == 0 // nach rechts
	cphieq := "3"
	f := 0
elseif xd > 0 .and. yd > 0
	cphieq := "4"
	f := (1.0*yd)/(1.0*xd)
elseif xd == 0 .and. yd > 0 // nach unten
	cphieq := "5"
	f := 0
elseif xd < 0 .and. yd > 0
	cphieq := "6"
	f := (1.0*xd)/(1.0*yd)
elseif xd < 0 .and. yd == 0 // nach links
	cphieq := "7"
	f := 0
elseif xd < 0 .and. yd < 0
	cphieq := "8"
	f := (1.0*yd)/(1.0*xd)
endif
f := abs(f)
cphieq += str(f,10,3)
csort := cphieq + " "+str(r,6,3)
return {csort,cphieq,0, r, iyt,ixt,  xd, yd}


function Task1(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

 
cfile := cdir+"input.txt"
c := ffileread(cfile)
a := string2array(c, crlf)
call := ""
nvisibmax := 0
for iy := 1 upto alen(a)
	c := a[iy]
	for ix := 1 upto len(c)
		cp := substr(c, ix, 1)
		if cp == "#"
			dlgprogressupdatetext(getshell(), typevalue2string(iy, ix))
			nvisib := macrofunc("calcvisib", {a, iy, ix})
			call += typevalue2string(iy, ix, ":", nvisib)+CRLF
			if nvisib > nvisibmax
				nvisibmax := nvisib
				iymin := iy
				ixmin := ix
			endif
		endif
	next 
next

msginfo (typevalue2string(nvisibmax, iymin, ixmin)+" "+call)

dlgProgressClose(getshell())

return 



function calcvisib (a, iy, ix)

nvisib := 0
call := ""
for iyt := 1 upto alen(a)
	c := a[iyt]
	for ixt := 1 upto len(c)
		if ixt <> ix .or. iyt <> iy
			cp := substr(c, ixt, 1)
			if cp == "#"
				ct := macrofunc("calcdiff",{ iy, ix,iyt, ixt})+crlf
				if at(ct, call) == 0
					nvisib += 1
					call += ct
				endif
			endif
		endif
	next 
next

return nvisib



function calcdiff (iy, ix, iyt, ixt)
xd := ixt -ix
yd := iyt -iy
r := xd *xd +yd *yd
r := sqrt(r)
xd := integer((1000.0 *xd) /r)
yd := integer((1000.0 *yd) /r)
return str(xd,5,0)+str(yd,5,0)
