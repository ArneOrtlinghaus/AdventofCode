function start()
cdir := "C:\_Arne\_adventofcode2019\day7\"
cdir := "D:\Prog\_adventofcode2019\day7\"
c := FExecuteVOScriptFile(cdir +"\prog.js", "Task",{cdir, 0})
return

function Task(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

cfile := cdir+"input.txt"
c := ffileread(cfile)
//c := "3,52,1001,52,-5,52,3,53,1,52,56,54,1007,54,5,55,1005,55,26,1001,54,-5,54,1105,1,12,1,53,54,53,1008,54,0,55,1001,55,1,55,2,53,55,53,4,53,1001,56,-1,56,1005,56,6,99,0,0,0,0,10"
c := strtran(c, " ", "")
a := string2array(c, ",")
for i := 1 upto alen(a)
   n := a[i] 
   arrayputmacro(a, i, val(n))
next  

nmax := 0

for i1 := 5 upto 9
dlgProgressupdatetext(getshell(), ntrim(i1))
 
for i2 := 5 upto 9
dlgProgressupdatetext(getshell(), ntrim(i1) + " " + ntrim(i2))

for i3 := 5 upto 9
dlgProgressupdatetext(getshell(), ntrim(i1) + " " + ntrim(i2)+ " " + ntrim(i3))
for i4 := 5 upto 9
dlgProgressupdatetext(getshell(), ntrim(i1) + " " + ntrim(i2)+ " " + ntrim(i3)+ " " + ntrim(i4))
for i5 := 5 upto 9
dlgProgressupdatetext(getshell(), ntrim(i1) + " " + ntrim(i2)+ " " + ntrim(i3)+ " " + ntrim(i4)+ " " + ntrim(i5))
if i1 <> i2 .and. i1 <> i3 .and. i1 <> i4 .and. i1 <> i5 ;
.and. i2 <> i3 .and. i2 <> i4 .and. i2 <> i5;
.and. i3 <> i4 .and. i3 <> i5;
.and. i4 <> i5

	ninput := 0
	nout := 0
	acode := {}
	aphase := {i1, i2, i3, i4, i5}
	astep := {}
	for iproc := 1 upto 5
		AAdd (acode, aclonemacro (a))
		//AAdd (aphase, 4+iproc)
		AAdd (astep, 0)
	next 
	coutput := ""
	lgoon := true
	iloop := 0
	do while lgoon .and. iloop < 100
		iloop += 1
		for iproc := 1 upto 5
			nphase := aphase[iproc]
			istep := astep[iproc]
			ac := acode[iproc]
			aout := macrofunc ("calc", {ac, nphase, ninput, istep})
			ninput := aout[1]
			if ninput > 0
				nout := ninput 
			endif
			istep := aout[2]
			APutone(astep, iproc, istep)
			linputphaseread := aout[3]
			lhalt := aout[4]
			if lhalt
				lgoon := false
			endif
		next

	enddo 

	if nout > nmax 
		nmax := nout 
	endif

		coutput := typevalue2string(aphase, nout, ninput, nmax) + crlf
		ffileappend (cdir+"output.txt", coutput)
		dlgProgressupdatetext(getshell(), ntrim(i1) + " " + ntrim(i2)+ " " + ntrim(i3)+ " " + ntrim(i4)+ " " + ntrim(i5)+ " " + ntrim(iloop)+ " " + str(ninput, 25,0)+ " " + str(nout, 25, 0))
	//coutput += typevalue2string(nout, aphase)+crlf


	endif
next
next
next
next
next


msginfo (typevalue2string(nout, coutput))

dlgProgressClose(getshell())

return 

function calc (a, nphase, ninput, istep)
//istep := 0
lgoon := true 
nmax := 0
nout := 0
lhalt := false

linputphaseread := istep <> 0
do while lgoon 
	nmax += 1
	
    istep1 := istep+1
	nopcode := a[istep1]
	copcode := strzero(nopcode,5,0)
	nopcode := val(substr(copcode, 4,2))
	cpmmode1 := substr(copcode, 3,1)
	cpmmode2 := substr(copcode, 2,1)
	cpmmode3 := substr(copcode, 1,1)
	if nopcode == 99
		lgoon := false 
		lhalt := true
	elseif nopcode == 1 .or. nopcode == 2
		if cpmmode1 == "0"
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if nopcode == 1 
		   nr := n1+n2 
		elseif nopcode == 2 
			nr := n1*n2 
		endif
		if cpmmode3 =="1"
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		npos3 := a[istep1+3]
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	elseif nopcode == 3 .or. nopcode == 4
		if nopcode == 3
			if !linputphaseread
				nr := nphase
				linputphaseread := true
			else
				nr := ninput
			endif
			npos3 := a[istep1+1]
			arrayputmacro(a, npos3+1, nr)
		else 
			if cpmmode1 == "0"
				npos1 := a[istep1+1]
				n1 := a[npos1+1]
			else 
				n1 := a[istep1+1]
			endif
			nout := n1
			lgoon := false
		endif
		istep += 2
	elseif nopcode == 5 .or. nopcode == 6
	// Opcode 5 is jump-if-true: if the first parameter is non-zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
    // Opcode 6 is jump-if-false: if the first parameter is zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
		if cpmmode1 == "0"
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 5 .and. n1 <> 0) .or. nopcode == 6 .and. n1 == 0)
			istep := n2 
		else 
			istep += 3 
		endif
	elseif nopcode == 7 .or. nopcode == 8
    // Opcode 7 is less than: if the first parameter is less than the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.
    // Opcode 8 is equals: if the first parameter is equal to the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.		
		if cpmmode1 == "0"
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 7 .and. n1 < n2) .or. nopcode == 8 .and. n1 == n2)
			nr := 1
		else 
			nr := 0
		endif
		if cpmmode3 =="1"
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		npos3 := a[istep1+3]
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	else 
		msgerror ("not allowed opcode" + typevalue2string(istep, copcode))
	endif
	if nmax > 999999
		msgerror ("too many iterations")
		exit
	endif
enddo

return {nout, istep, linputphaseread, lhalt}




for i1 := 0 upto 4
dlgProgressupdatetext(getshell(), ntrim(i1))
 
for i2 := 0 upto 4

for i3 := 0 upto 4
for i4 := 0 upto 4
for i5 := 0 upto 4
if i1 <> i2 .and. i1 <> i3 .and. i1 <> i4 .and. i1 <> i5 ;
.and. i2 <> i3 .and. i2 <> i4 .and. i2 <> i5;
.and. i3 <> i4 .and. i3 <> i5;
.and. i4 <> i5
nout := 0
nout := macrofunc ("calc", {a, i1,nout})
nout := macrofunc ("calc", {a, i2,nout})
nout := macrofunc ("calc", {a, i3, nout})
nout := macrofunc ("calc", {a, i4,nout})
nout := macrofunc ("calc", {a, i5,nout})
if nout > nmax 
nmax := nout 
endif
endif
next
next
next
next
next
