function Task1(cdir)

aintcode := macrofunc ("readintcode", {cdir})
aputone (aintcode,1,2)
ainput :={}

aout := ACreateTwo(23, 43, 0)

aout := macrofunc ("calcintcode", {aintcode, ainput,aout})
coutput := aout[2]
//msginfo (coutput)
//a := string2array(coutput, ",")
//a := macrofunc ("calcscr", {a})
//msginfo(typevalue2string(a))
//c := macrofunc ("arraytostring", {a})
//msginfo(c)

return 





function readintcode(cdir) 

cfile := cdir+"input.txt"
c := ffileread(cfile)
//c := "109,1,204,-1,1001,100,1,100,1008,100,16,101,1006,101,0,99"
//c := "1102,34915192,34915192,7,4,7,99,0"
//c := "104,1125899906842624,99"
c := strtran(c, " ", "")
a := string2array(c, ",")
for i := 1 upto alen(a)
   n := a[i] 
   arrayputmacro(a, i, val(n))
next  

return a

function calcintcode (a, ainput,aout)
lgoon := true 
a := aclonemacro(a)
for i := 1 upto 100//00
aadd (a,0)
next
nmax := 0
nout := 0
coutput := ""
lhalt := false
istep := 0
ninput := 0
nbase := 0
cprot := ""

noutputpos := 0
ix := 0
iy := 0
lout := false
odta := nil
noption := 2
nscore := 0


do while lgoon 
	nmax +=1
	
    istep1 := istep+1
	nopcode := a[istep1]
	copcode := strzero(nopcode,5,0)
	nopcode := val(substr(copcode, 4,2))
	cpmmode1 := substr(copcode, 3,1)
	cpmmode2 := substr(copcode, 2,1)
	cpmmode3 := substr(copcode, 1,1)
	//cprot += crlf+typevalue2string(copcode, "OP", nopcode)+crlf
	//cprot += "       "+typevalue2string(cpmmode1, cpmmode2, cpmmode3, istep)+crlf
	//cprot += "       "+typevalue2string(a[istep1], a[istep1+1], a[istep1+2], a[istep1+3])+crlf 
	//coutput += "OP"+typevalue2string(nopcode, istep) 
	if nopcode == 99
		lgoon := false 
		lhalt := true
	elseif nopcode == 1 .or. nopcode == 2
		if cpmmode1 == "0" 
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2"    
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0" 
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		elseif cpmmode2 == "2" 
			npos2 := a[istep1+2]
			npos2 += nbase
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if nopcode == 1 
		   nr := n1+n2 
		   //cprot += "       +"+typevalue2string(n1,n2,nr)+crlf 
		elseif nopcode == 2 
			nr := n1*n2 
			//cprot += "       x"+typevalue2string(n1,n2,nr)+crlf 
		endif
		 
		if cpmmode3 =="1" 
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		
		npos3 := a[istep1+3]
		if cpmmode3 == "2"
			npos3 += nbase
		endif
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	elseif nopcode == 3 .or. nopcode == 4
		if nopcode == 3
			ninput += 1
         if !lout
         lout := true
         odta := getshell():searchshowchild(#dtaShowInfoHTML, 0, 0, 0xFFFF)
         endif
         nd := macrofunc ("arraytostring", {aout,nscore,odta})
   
         if nd > 0
            nr := -1
         elseif nd < 0
            nr := 1
         else 
            nr := 0
         endif
         
         
			
				
			npos3 := a[istep1+1]
			if cpmmode1 == "2"
				npos3 += nbase
			endif
			//cprot += "      IN"+typevalue2string(nr, ninput, npos3)+crlf 
			arrayputmacro(a, npos3+1, nr)
		else 
			if cpmmode1 == "0" 
				npos1 := a[istep1+1]
				n1 := a[npos1+1]
			elseif cpmmode1 == "2" 
				npos1 := a[istep1+1]
				npos1 += nbase
				n1 := a[npos1+1]
			else 
				n1 := a[istep1+1]
			endif
			//cprot += "     OUT"+typevalue2string(n1)+crlf
			nout := n1
         noutputpos +=1
         if noutputpos > 3
            noutputpos := 1
         endif
         if noutputpos = 1
            ix := n1
         elseif noutputpos = 2
            iy := n1
         else 
            if ix == -1 .and. iy == 0
            nscore := nout
            nd := macrofunc ("arraytostring", {aout,nscore,odta})
            
            else 
               APutTwo(aout, iy+1, ix+1, nout)
            endif
            //macrofunc ("outscr",{aout, ix,iy,nout,lout, odta})
         endif
         debugout (typevalue2string(noutputpos, nout))
			coutput := addstring(coutput, alltrim(str(nout, -1,0)), ",")
			
		endif
		istep += 2
	elseif nopcode == 5 .or. nopcode == 6
	// Opcode 5 is jump-if-true: if the first parameter is non-zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
    // Opcode 6 is jump-if-false: if the first parameter is zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
		if cpmmode1 == "0"  
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2" 
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0" 
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		elseif cpmmode2 == "2" 
			npos2 := a[istep1+2]
			npos2 += nbase
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 5 .and. n1 <> 0) 
			istep := n2 
			//cprot += "     JPTRUE <> 0"+typevalue2string(n1, n2)+crlf
		elseif nopcode == 6 .and. n1 == 0)
			istep := n2 
			//cprot += "     JPFALSE == 0"+typevalue2string(n1, n2)+crlf
		else 
			istep += 3 
			if nopcode == 5
				//cprot += "     NO JPbecause false,==0"+typevalue2string(n1, n2)+crlf
			else
				//cprot += "     NO JPbecause true,<>0"+typevalue2string(n1, n2)+crlf
			endif
		endif
	elseif nopcode == 7 .or. nopcode == 8
    // Opcode 7 is less than: if the first parameter is less than the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.
    // Opcode 8 is equals: if the first parameter is equal to the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.		
		if cpmmode1 == "0"  
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2" 
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"  
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		elseif cpmmode2 == "2"  
			npos2 := a[istep1+2]
			npos2 += nbase
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 7 .and. n1 < n2) 
			nr := 1
			//cprot += "     LT"+typevalue2string(n1, n2)+crlf
		elseif nopcode == 8 .and. n1 == n2)
			nr := 1
			//cprot += "     EQ"+typevalue2string(n1, n2)+crlf
		else 
			nr := 0
			if nopcode == 7
				//cprot += "     0 because GE"+typevalue2string(n1, n2)+crlf
			else
				//cprot += "     0 because NE"+typevalue2string(n1, n2)+crlf
			endif
		endif
		
		if cpmmode3 =="1" 
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		
		npos3 := a[istep1+3]
		if cpmmode3 == "2" 
			npos3 += nbase
		endif
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	elseif nopcode == 9
	// Opcode 9 adjusts the relative base by the value of its only parameter. The relative base increases (or decreases, if the value is negative) by the value of the parameter.
		if cpmmode1 == "0" 
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		elseif cpmmode1 == "2"    
			npos1 := a[istep1+1]
			npos1 += nbase
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		nbase += n1
		//cprot += "     NBASE"+typevalue2string(n1, nbase)+crlf
		istep += 2
	else 
		msgerror ("not allowed opcode" + typevalue2string(istep, copcode))
	endif
	if nmax > 999999
		msgerror ("too many iterations")
		exit
	endif
enddo

return {nout, coutput, istep, cprot}


function arraytostring(a,nscore,odta)
c := ""
ix4 := 0
iy4 := 0
ix3 := 0
iy3 := 0
for iy := 1 upto alen(a)
   for ix := 1 upto alen(a[iy])
      n := a[iy,ix]
      if n == 4
         ix4 := ix
         iy4 := iy
      endif
      if n == 3
         ix3 := ix
         iy3 := iy
      endif
      c += ntrim(n)
   next 
   c +=crlf
next
c := strtran(c, ",", "")
c := strtran(c, "0", "_")

c += crlf+"score: " +ntrim(nscore)+crlf
c += "xd: " +ntrim(ix3-ix4)+" yd: " +ntrim(iy3-iy4)+crlf
oformattedtext := safecreateinstance(#clsformattedtexthtml)
oformattedtext:AddText(c, "COURIER", nil/*fontsize*/, true/*bold*/)
c := oformattedtext:Maketext()
if !empty(odta)
odta:setinfo('arcade', c, nil)
endif
return ix3-ix4



aOptions :={}
AAdd(aOptions,{"links", 1})
AAdd(aOptions,{"bleibt", 2})
AAdd(aOptions,{"rechts", 3})

noption := InputOptionEx(getshell()/*insert correct Ownerwindow here*/, "joystick", "joystick", aOptions, ;
noption, true/*lDisplayAlsowithOneOption*/, false/*lWithOptionDescription*/, nil)
         
         if noption == 1
         nr := -1
         elseif noption == 2
         nr := 0
         else 
            nr := 1
         endif