function start()
cdir := "D:\Prog\_adventofcode2019\day5\"
//cdir := "C:\_Arne\_adventofcode2019\day5\"
c := FExecuteVOScriptFile(cdir +"\prog.js", "Task",{cdir, 0})
return

function Task(cdir, ntask) 
dlgProgressInit(getshell(), "Test"/*Caption*/, true/*Abbruch möglich*/)

cfile := cdir+"input.txt"
c := ffileread(cfile)
//c := "3,9,8,9,10,9,4,9,99,-1,8"
//c := "3,9,7,9,10,9,4,9,99,-1,8"
//c := "3,3,1108,-1,8,3,4,3,99"
//c := "3,3,1107,-1,8,3,4,3,99"
c := strtran(c, " ", "")
a := string2array(c, ",")
for i := 1 upto alen(a)
   n := a[i] 
   arrayputmacro(a, i, val(n))
next  

//if ntask == 1
cout := macrofunc ("calc", {a, 5})
msginfo (typevalue2string(cout, a))

dlgProgressClose(getshell())

return 

function calc (a, ninput)
cout := ""
istep := 0
lgoon := true 
nmax := 0
do while lgoon 
	nmax += 1
	
    istep1 := istep+1
	nopcode := a[istep1]
	copcode := strzero(nopcode,5,0)
	nopcode := val(substr(copcode, 4,2))
	cpmmode1 := substr(copcode, 3,1)
	cpmmode2 := substr(copcode, 2,1)
	cpmmode3 := substr(copcode, 1,1)
	if nopcode == 99
		lgoon := false 
	elseif nopcode == 1 .or. nopcode == 2
		if cpmmode1 == "0"
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if nopcode == 1 
		   nr := n1+n2 
		elseif nopcode == 2 
			nr := n1*n2 
		endif
		if cpmmode3 =="1"
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		npos3 := a[istep1+3]
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	elseif nopcode == 3 .or. nopcode == 4
		if nopcode == 3
			nr := ninput 
			npos3 := a[istep1+1]
			arrayputmacro(a, npos3+1, nr)
		else 
			if cpmmode1 == "0"
				npos1 := a[istep1+1]
				n1 := a[npos1+1]
			else 
				n1 := a[istep1+1]
			endif
			cout += ntrim(n1)+";"
		endif
		istep += 2
	elseif nopcode == 5 .or. nopcode == 6
	// Opcode 5 is jump-if-true: if the first parameter is non-zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
    // Opcode 6 is jump-if-false: if the first parameter is zero, it sets the instruction pointer to the value from the second parameter. Otherwise, it does nothing.
		if cpmmode1 == "0"
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 5 .and. n1 <> 0) .or. nopcode == 6 .and. n1 == 0)
			istep := n2 
		else 
			istep += 3 
		endif
	elseif nopcode == 7 .or. nopcode == 8
    // Opcode 7 is less than: if the first parameter is less than the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.
    // Opcode 8 is equals: if the first parameter is equal to the second parameter, it stores 1 in the position given by the third parameter. Otherwise, it stores 0.		
		if cpmmode1 == "0"
			npos1 := a[istep1+1]
			n1 := a[npos1+1]
		else 
			n1 := a[istep1+1]
		endif
		if cpmmode2 == "0"
			npos2 := a[istep1+2]
			n2 := a[npos2+1]
		else 
			n2 := a[istep1+2] 
		endif
		if (nopcode == 7 .and. n1 < n2) .or. nopcode == 8 .and. n1 == n2)
			nr := 1
		else 
			nr := 0
		endif
		if cpmmode3 =="1"
			msgerror ("cpmmode3 ==1" + typevalue2string(istep, copcode))
		endif
		npos3 := a[istep1+3]
		arrayputmacro(a, npos3+1, nr)
		istep += 4
	else 
		msgerror ("not allowed opcode" + typevalue2string(istep, copcode))
	endif
	if nmax > 999999
		msgerror ("too many iterations")
		exit
	endif
enddo

return cout
